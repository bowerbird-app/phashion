/* confdefs.h */
#define PACKAGE_NAME "pHash"
#define PACKAGE_TARNAME "phash"
#define PACKAGE_VERSION "0.9.6"
#define PACKAGE_STRING "pHash 0.9.6"
#define PACKAGE_BUGREPORT "support@phash.org"
#define PACKAGE_URL ""
#define PACKAGE "pHash"
#define VERSION "0.9.6"
